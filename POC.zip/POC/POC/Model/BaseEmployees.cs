﻿using System;
using System.Collections.Generic;
using System.Text;

namespace POC.Model
{
    class BaseEmployees
    {
        public int UserId { get; set; }

        public string FirstName { get; set; }

        public string UserCompany { get; set; }

        public string UserDesignation { get; set; }
    }
}
